function res = svmFeature(magnitude)
res = sum(magnitude) / length(magnitude);
end