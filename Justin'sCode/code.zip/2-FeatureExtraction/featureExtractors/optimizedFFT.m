function Y = optimizedFFT(data, fourierTransform)
Y =  step(fourierTransform,data);
end