function result = energy(signal)
result = rms(signal)^2;
end